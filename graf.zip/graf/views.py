# views.py

from django.shortcuts import render
import networkx as nx
import matplotlib.pyplot as plt
from io import BytesIO
import base64

def generate_plot(G, shortest_path):
    fig, ax = plt.subplots()
    pos = nx.spring_layout(G)

    if G.is_directed():
        nx.draw(G, pos, with_labels=True, font_weight='bold', arrows=True, ax=ax)
    else:
        nx.draw(G, pos, with_labels=True, font_weight='bold', arrows=False, ax=ax)

    nx.draw_networkx_nodes(G, pos, nodelist=shortest_path, node_color='r', ax=ax)
    nx.draw_networkx_edges(G, pos, edgelist=list(zip(shortest_path, shortest_path[1:])), edge_color='r', ax=ax)

    # Additional text
    plt.text(0, -0.1, "   sayfullayev_0204", horizontalalignment='center', verticalalignment='center', transform=ax.transAxes, fontsize=14, color='black')

    # Calculate total distance of the shortest path
    total_distance = nx.shortest_path_length(G, source=shortest_path[0], target=shortest_path[-1])

    # Add a 'weight' attribute to each edge in the graph
    for edge in G.edges():
        G[edge[0]][edge[1]]['weight'] = 1

    # Calculate sum of edge weights up to the shortest path length
    sum_edge_weights = sum(G[edge[0]][edge[1]]['weight'] for edge in zip(shortest_path, shortest_path[1:]) if 'weight' in G[edge[0]][edge[1]])

    # Normalize edge weights so that the shortest distance becomes 1
    edge_weights = nx.get_edge_attributes(G, 'weight')
    normalized_weights = {edge: 1 / weight for edge, weight in edge_weights.items()}
    nx.set_edge_attributes(G, normalized_weights, 'normalized_weight')

    # Convert the Matplotlib object to a byte array
    img_data = BytesIO()
    plt.savefig(img_data, format='png')
    img_data.seek(0)
    img_base64 = base64.b64encode(img_data.read()).decode('utf-8')
    plt.close()

    return img_base64, total_distance, sum_edge_weights

def index(request):
    if request.method == 'POST':
        nodes_input = request.POST.get('nodes', '')
        edges_input = request.POST.get('edges', '')
        source = int(request.POST.get('source', 0))
        target = int(request.POST.get('target', 0))
        action = request.POST.get('action', '')

        nodes = [int(node.strip()) for node in nodes_input.split(' ')]
        edges_raw = [edge.strip() for edge in edges_input.split(' ')]
        edges = [tuple(map(int, edge.split('-'))) for edge in edges_raw]

        G = nx.Graph()  # Use undirected graph for the default case
        if action == 'with_arrows':
            G = nx.DiGraph()

        G.add_nodes_from(nodes)
        G.add_edges_from(edges)

        ancestors = nx.ancestors(G.reverse() if action == 'with_arrows' else G, source=source)
        if target in ancestors:
            shortest_path = nx.shortest_path(G, source=source, target=target)

            # Calculate total distance, normalize edge weights, and sum of edge weights
            plot_data, total_distance, sum_edge_weights = generate_plot(G, shortest_path)

            return render(request, 'index.html', {'plot_data': plot_data,
                                                   'shortest_path': shortest_path,
                                                   'total_distance': total_distance,
                                                   'sum_edge_weights': sum_edge_weights})
        else:
            return render(request, 'index.html', {'error': "Ushbu maqsadga yo'l topilmadi."})

    return render(request, 'index.html')
