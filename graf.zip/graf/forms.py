from django import forms

class GraphForm(forms.Form):
    nodes = forms.CharField(label='Uchlar', help_text='Graf uchlarini kiriting (Namuna: 1.2.3 ...)')
    edges = forms.CharField(label='Tugunlar', help_text='Graf tugunlarini kiriting (Namuna: 1-2. 2-3 ...)')
